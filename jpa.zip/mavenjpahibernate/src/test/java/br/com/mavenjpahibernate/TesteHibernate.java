package br.com.mavenjpahibernate;

import org.junit.Test;



public class TesteHibernate {
	
	@Test
	public void testeHibernateUtil() {
		HibernateUtil.getEntityManager();
	}

}
